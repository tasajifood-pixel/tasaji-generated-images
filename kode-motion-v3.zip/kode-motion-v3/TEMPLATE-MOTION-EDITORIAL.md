# TEMPLATE RESMI — Motion Editorial Dakwah (gaya: `motion-editorial`)

Dibuat dari arahan Abi, 23 November 2026. **Status: RESMI sebagai gaya desain, di-ACC Abi 23 November 2026 setelah revisi font dan transisi v2. Video contoh tetap tidak dijadwalkan tayang.** Referensi: dua video motion-graphics yang dikirim Abi; visual disusun orisinal, tidak menyalin identitas kreator.

## 1. Nuansa dan tujuan
Konten dakwah cepat, jelas, visual dinamis: gagasan abstrak dibuat terasa konkret lewat tipografi besar, garis perjalanan, ilustrasi geometris, kartu kutipan, dan perpindahan adegan yang terasa dirancang. Tetap khidmat, bukan komedi atau hiburan kosong.

## 2. Cocok / tidak cocok
Cocok: AKHIRAT, ADAB, AKHLAK, FIKIH praktis, nasihat satu hadis. Mode: renungan, ajakan, targhib. Tidak cocok: detail fiqih yang memerlukan uraian panjang, visualisasi Nabi/sahabat/gaib, konten yang hanya mengejar sensasi.

## 3. Alur video contoh (47,8 detik)
- Detik 0–5: pertanyaan pemantik, simbol waktu (jam pasir)
- 5–17: umur berkurang, hal dunia ditinggalkan, esok tak dijamin
- 17–28: kartu hadis **HR. Al-Bukhari 6416** dalam Arab + terjemahan
- 28–36: metafora rute singgah, koper bekal
- 36–44: tiga langkah tobat (grafik checklist)
- 44–47,8: penutup dan sumber, tanpa watermark identitas

## 4. Tampilan dan tipografi
- Rasio 9:16; 1080×1920; 30 fps. Safe area judul & CTA tetap di bagian tengah, area bawah untuk watermark.
- Palet: hijau terang `#B6CE66`, olive `#849C3B`, kuning `#F6D578`, tinta `#18252F`, dasar `#F6F5ED`. Bergerak dari terang ke gelap sesuai emosi.
- Font heading: **Bricolage Grotesque Variable** (berkarakter dan modern), badan/UI: **Plus Jakarta Sans Variable**, kutipan editorial: **Fraunces Variable**, Arab: Geeza Pro (harus dievaluasi keterbacaan bersama standar Arab produksi).
- Font Latin sumber: Google Fonts OFL (lisensi ada di direktori aset produksi). Tidak mengekspor berkas font ke penonton.

## 5. Perpindahan/transisi — bukan crossfade polos
Tujuh mesin transisi tersedia, dipilih sesuai logika visual:
1. `diagonal`: reveal serong dengan pita hijau-kuning tebal seperti acuan Abi
2. `shutters`: enam panel vertikal bergerak bergantian
3. `iris`: bukaan lingkaran yang membesar mengikuti pusat perhatian
4. `flip`: halaman UI lipat tiga dimensi dengan perspektif
5. `reverse`: diagonal dari arah kebalikan untuk variasi
6. `portal`: dari kartu kecil yang mengembang memenuhi layar
7. `split`: dua belahan bergerak berlawanan lalu bertemu

Transisi 24 frame/0,8 detik; mulai sekitar 0,55 detik sebelum segmen narasi berikutnya, selesai pada awal segmen. Tidak semua gerakan harus dipakai berurutan di tiap konten; pilih untuk ritme dan isi. Hindari motion sickness atau gerak berlebihan.

## 6. Audio, footage, batasan syariat
Narasi satu suara tempo asli, **Puck tetap target produksi resmi**. Prototipe v2 memakai Ardi Neural untuk menguji editing, tidak boleh diklaim memakai Puck. Efek suara buatan sendiri: whoosh/panel/klik pendek, tanpa musik atau instrumen. Tidak ada gambar orang AI, makhluk gaib, hewan, atau visual Nabi/sahabat. Teks Arab harus sesuai sumber, bukan improvisasi.

## 7. Sampul
Satu berkas JPG 1080×1920, judul 2–6 kata dalam area aman kisi TikTok, tanpa watermark atau identitas akun. Komposisi dari frame grafis sejenis dengan video, bukan frame acak. Untuk prototipe: **DUNIA HANYA PERSINGGAHAN**.

## 8. Gerbang dan validasi untuk setiap produksi
- Cek ayat/hadis terhadap sumber dan tafsir; terjemahan tepat; tidak ada penggambaran yang dilarang.
- Cek semua 10 sambungan adegan lewat cuplikan, subtitle/naskah/teks tidak terpotong, font benar dimuat.
- 1080×1920; h264/AAC; 9:16; durasi wajar; faststart; audio tidak clipping; tanpa musik.
- Jalankan gerbang produksi baku Bank Dakwah/Jiraga bila masuk pipeline; video uji belum dianggap lulus gerbang ini sampai dicek.
- Gaya, transisi, font, dan contoh v2 telah di-ACC Abi; **setiap video produksi berikutnya tetap wajib ACC dan lulus gerbang tersendiri**.

## 9. Lokasi komponen dan contoh
- `~/Projects/tasaji-video-studio/src/MotionDakwahPrototype.tsx`
- `~/Projects/tasaji-video-studio/src/MotionDakwahTransitions.tsx`
- `~/Projects/tasaji-video-studio/src/MotionDakwahFonts.css`
- `~/tasaji-dakwah/uji-motion-grafis-20261123/`
- Contoh acuan yang di-ACC: `UJI-MOTION-20261123-01` — *Dunia Hanya Persinggahan*, HR. Al-Bukhari 6416.

**Belum** memasukkan contoh ke penayangan/publikasi. Kode template telah berstatus resmi; contoh video tidak otomatis lolos gerbang produksi Jiraga.

> Arahan Abi 23 Nov 2026 (berlaku untuk semua template): TANPA watermark/identitas @renungan.iman.id di video maupun sampul — biar bebas dibagikan.


## 10. Acuan ACC final (23 November 2026)
- Video contoh 47,8 detik tanpa watermark: https://apk.tasajifood.com/ruhraga/pustaka/review/motion-editorial-dunia-persinggahan-acc-20261123-a086d2fa540492cc.mp4
- Sampul tanpa watermark: https://apk.tasajifood.com/ruhraga/pustaka/review/motion-editorial-dunia-persinggahan-sampul-acc-20261123-9b2514f3500d163f.jpg
- Status gaya **RESMI** berdasarkan ACC Abi; belum ACC tayang untuk contoh tersebut, masih perlu persyaratan suara Puck, gerbang dalil/footage, dan subtitle per kata apabila diimpor Jiraga. Tidak menjadwalkan publikasi otomatis.
