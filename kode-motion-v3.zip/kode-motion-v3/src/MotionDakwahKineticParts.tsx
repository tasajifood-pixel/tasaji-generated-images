import React from "react";
import {useCurrentFrame} from "remotion";
const ink="#18252F", green="#B6CE66", olive="#849C3B", gold="#F3D377", white="#FFFEF8";
const font="'Dakwah Jakarta',Arial,sans-serif";
const display="'Dakwah Bricolage','Dakwah Jakarta',Arial,sans-serif";
const sat=(x:number)=>Math.max(0,Math.min(1,x));
const ease=(v:number)=>{const x=sat(v);return 1-Math.pow(1-x,3);};
const wiggle=(f:number,speed=.08,size=7,phase=0)=>Math.sin(f*speed+phase)*size;

export function KineticWords({text,f,start=0,accent="",dark=false}:{text:string,f:number,start?:number,accent?:string,dark?:boolean}){
 const words=text.split(/\s+/).filter(Boolean);
 return <span style={{display:"block",whiteSpace:"nowrap"}}>
 {words.map((word,i)=>{
  const k=ease((f-start-i*4.2)/13);
  const emph=accent.length>0 && word.toLowerCase().replace(/[.,?!]/g,"")===accent.toLowerCase().replace(/[.,?!]/g,"");
  const pulse=emph&&k>.99?1+wiggle(f,.08,.014,i):1;
  return <span key={i}style={{
   display:"inline-block",position:"relative",marginRight:i===words.length-1?0:"0.21em",
   opacity:k,
   transform:"translateY("+((1-k)*59)+"px) rotate("+((1-k)*-6)+"deg) scale("+((.92+.08*k)*pulse)+")",
   transformOrigin:"center bottom",
   color:emph?(dark?green:olive):undefined
  }}>
   {word}
   {emph&&<span style={{position:"absolute",bottom:-2,left:0,right:0,height:9,
     background:gold,opacity:.85,transformOrigin:"left center",transform:"scaleX("+ease((f-start-i*4-14)/18)+")"}}/>}
  </span>;
 })}
 </span>;
}
export function KineticPhrase({text,f,start=0,dark=false,size=36}:{text:string,f:number,start?:number,dark?:boolean,size?:number}){
 return <span style={{display:"inline-flex",flexWrap:"wrap",justifyContent:"center",gap:12,
 fontFamily:font,fontWeight:770,fontSize:size,color:dark?white:ink}}>
 {text.split(" ").map((word,i)=>{const k=ease((f-start-i*3)/13);
 return <span key={i} style={{opacity:k,display:"inline-block",
   transform:"translateY("+((1-k)*34)+"px)",filter:"blur("+((1-k)*2)+"px)"}}>{word}</span>;
 })}
 </span>;
}
export function AmbientMotion({dark=false,idx=0}:{dark?:boolean,idx?:number}){
 const f=useCurrentFrame();
 return <div style={{position:"absolute",inset:0,pointerEvents:"none",overflow:"hidden"}}>
  <div style={{position:"absolute",left:-260+200*Math.sin(f*.008+idx),top:410+260*Math.sin(f*.009+idx),
     width:590,height:590,borderRadius:"50%",border:"4px dashed "+(dark?"rgba(182,206,102,.18)":"rgba(132,157,64,.17)"),
     transform:"rotate("+(f*.4)+"deg)"}}/>
  <div style={{position:"absolute",right:-260+150*Math.cos(f*.008+idx),bottom:200+210*Math.sin(f*.006+idx),
     width:480,height:480,borderRadius:"50%",border:"3px solid "+(dark?"rgba(243,211,119,.1)":"rgba(231,164,108,.17)"),
     transform:"scale("+(1+.09*Math.sin(f*.03))+")"}}/>
  {Array.from({length:9},(_,i)=><div key={i}style={{
    position:"absolute",left:90+(i*113+idx*79)%890,
    top:240+(i*213)%1320+wiggle(f,.019,39,i),
    width:i%3===0?10:6,height:i%3===0?10:6,borderRadius:"50%",
    opacity:.12+.06*Math.sin(f*.07+i),
    background:dark?green:olive
  }}/>)}
 </div>;
}
export function PhoneReminder({f}:{f:number}){
 const k=ease((f-5)/20);
 const notif=ease((f-23)/15);
 const press=ease((f-57)/12);
 return <div style={{
   position:"relative",width:552,height:676,marginTop:60,
   transform:"translateY("+wiggle(f,.055,10)+"px) rotate("+wiggle(f,.022,1.8)+"deg) scale("+(.88+.12*k)+")",
   opacity:k
  }}>
  <div style={{position:"absolute",inset:0,borderRadius:65,background:"#111D24",border:"8px solid "+gold,boxShadow:"20px 21px 0 rgba(0,0,0,.24)"}}>
    <div style={{position:"absolute",top:21,left:196,width:151,height:13,borderRadius:8,background:"#4B5C64"}}/>
    <div style={{position:"absolute",left:20,top:52,right:20,bottom:21,background:white,borderRadius:34,overflow:"hidden"}}>
      <div style={{height:85,padding:"0 30px",display:"flex",alignItems:"center",justifyContent:"space-between",
       background:"#DDE9C8",fontFamily:font,fontWeight:850,fontSize:26}}>
       <span>CATATAN HARI INI</span><span style={{fontSize:37,transform:"rotate("+(f*2)+"deg)"}}>◷</span>
      </div>
      <div style={{margin:35}}>
        <div style={{fontFamily:font,color:"#788480",fontSize:25,fontWeight:840,letterSpacing:3}}>PENGINGAT</div>
        <div style={{fontFamily:display,color:ink,fontSize:81,fontWeight:840,lineHeight:1.02,marginTop:22}}>Jangan<br/>ditunda.</div>
        <div style={{height:8,width:(35+54*ease((f-27)/40))+"%",background:green,borderRadius:12,marginTop:30}}/>
        <div style={{fontFamily:font,fontWeight:800,fontSize:36,color:ink,marginTop:39}}>Kembali kepada Allah</div>
        <div style={{display:"flex",alignItems:"center",gap:21,marginTop:25}}>
         <div style={{width:65,height:65,boxSizing:"border-box",border:"4px solid "+ink,borderRadius:14,
           background:press>.6?green:white,textAlign:"center",fontSize:48,fontWeight:900,lineHeight:"56px"}}>{press>.6?"✓":""}</div>
         <div style={{fontFamily:font,fontWeight:760,fontSize:31,color:ink}}>Mulai sekarang</div>
        </div>
      </div>
      <div style={{position:"absolute",bottom:24,right:28,fontFamily:font,fontSize:27,fontWeight:880,color:olive}}>SEKARANG ↗</div>
    </div>
  </div>
  <div style={{position:"absolute",top:58,left:330,width:310,background:green,borderRadius:18,
    border:"3px solid "+ink,padding:"22px 19px",fontFamily:font,fontWeight:840,fontSize:26,
    boxShadow:"8px 9px 0 "+ink,opacity:notif,transform:"translateX("+((1-notif)*220)+"px) rotate("+((1-notif)*15)+"deg)"}}>
     INGAT TOBAT HARI INI
  </div>
 </div>;
}
export function CheckAnimation({f,index=0,size=70}:{f:number,index?:number,size?:number}){
 const k=ease((f-18-index*13)/12);
 return <div style={{width:size,height:size,border:"5px solid "+ink,
   background:k>.7?green:white,borderRadius:17,boxSizing:"border-box",
   display:"grid",placeItems:"center",fontFamily:font,fontWeight:900,fontSize:size*.65,
   transform:"scale("+(.88+.12*k)+")"}}>
   <span style={{opacity:k,transform:"scale("+k+")"}}>✓</span>
 </div>;
}
export function SourceSeal({f}:{f:number}){
 const k=ease((f-23)/23);
 return <svg viewBox="0 0 215 215"width="215"height="215"style={{
   transform:"rotate("+((1-k)*-70)+"deg) scale("+(.4+.6*k)+")",opacity:k
 }}>
   <circle cx="107"cy="107"r="95"fill={green}stroke={ink}strokeWidth="9"/>
   <path d="M57 107L88 136L156 69"stroke={ink}strokeWidth="17"strokeLinecap="round"strokeLinejoin="round"
      fill="none"strokeDasharray="180"strokeDashoffset={180*(1-ease((f-40)/22))}/>
 </svg>;
}
export function PackingTokens({f}:{f:number}){
 return <div style={{position:"absolute",inset:0,pointerEvents:"none"}}>
 {["IMAN","TOBAT","AMAL"].map((s,i)=>{
  const r=ease((f-i*10)/12),fall=ease((f-31-i*10)/22);
  return <div key={i}style={{
     position:"absolute",left:24+i*206,top:-92,
     border:"3px solid "+ink,borderRadius:17,padding:"14px 19px",
     fontFamily:display,fontSize:43,fontWeight:850,
     background:i===1?green:white,boxShadow:"8px 8px 0 "+ink,
     opacity:r*(1-.88*fall),transform:"translateY("+((1-r)*-75+fall*385)+"px) rotate("+((1-r)*-12+fall*8)+"deg) scale("+(1-.2*fall)+")"
  }}>{s}</div>;
 })}
 </div>;
}
export function SourceUnderline({f,start=18}:{f:number,start?:number}){
 return <div style={{height:7,width:"85%",margin:"24px auto",background:"#D8DED0",borderRadius:10,overflow:"hidden"}}>
 <div style={{height:"100%",width:(100*ease((f-start)/30))+"%",background:olive,borderRadius:10}}/>
 </div>;
}
export function MovingRouteMarker({f,duration}:{f:number,duration:number}){
 const pts=[[90,455],[168,394],[209,266],[300,143],[387,151],[483,256],[580,400],[683,340],[827,125]];
 const q=ease(f/duration)*(pts.length-1);
 const idx=Math.min(pts.length-2,Math.floor(q));
 const v=q-idx, x=pts[idx][0]+(pts[idx+1][0]-pts[idx][0])*v, y=pts[idx][1]+(pts[idx+1][1]-pts[idx][1])*v;
 return <g transform={"translate("+x+" "+y+")"}>
 <circle cx="0"cy="0"r="28"fill={gold}stroke={ink}strokeWidth="7"/>
 <path d="M-10 0L0-12L10 0M0-10V11"fill="none"stroke={ink}strokeWidth="5"strokeLinecap="round"/>
 </g>;
}
export function StoryMotionLabel({text,f,dark=false}:{text:string,f:number,dark?:boolean}){
 const k=ease((f-9)/16);
 return <div style={{fontFamily:font,fontWeight:780,fontSize:31,
 color:dark?white:"#61736D",opacity:k,transform:"translateY("+((1-k)*32+wiggle(f,.05,3))+"px)"}}>
  {text}
 </div>;
}