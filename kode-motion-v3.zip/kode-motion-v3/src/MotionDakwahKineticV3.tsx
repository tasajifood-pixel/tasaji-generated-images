import React from "react";
import {AbsoluteFill, Audio, Composition, Sequence, staticFile, useCurrentFrame, interpolate, Easing} from "remotion";
import timeline from "./motion-single-puck-timeline.json";
import {TransitionScreen} from "./MotionDakwahTransitions";
import "./MotionDakwahFonts.css";
import { KineticWords, KineticPhrase, AmbientMotion, PhoneReminder, CheckAnimation, SourceSeal, PackingTokens, SourceUnderline, MovingRouteMarker, StoryMotionLabel } from "./MotionDakwahKineticParts";

const FPS=30, WIDTH=1080, HEIGHT=1920, TOTAL=Math.ceil((timeline.total+.3)*FPS);
const col={paper:"#F6F5ED",white:"#FFFEF8",ink:"#18252F",ink2:"#2B3941",green:"#B6CE66",olive:"#849C3B",orange:"#E6A36B",muted:"#6B7880"};
const font="'Dakwah Jakarta','Avenir Next',Arial,sans-serif";
const display="'Dakwah Bricolage','Dakwah Jakarta',sans-serif";
const serif="'Dakwah Fraunces',Georgia,serif";
const clamp=(x:number,a:number,b:number)=>Math.max(a,Math.min(b,x));
const prog=(f:number,start:number,end:number)=>clamp((f-start)/(end-start),0,1);
const title=(color=col.ink):React.CSSProperties=>({color,fontFamily:display,fontWeight:800,fontSize:105,lineHeight:1.09,letterSpacing:-3,textAlign:"center"});
const small=(color=col.ink):React.CSSProperties=>({color,fontFamily:font,fontWeight:700,fontSize:36,lineHeight:1.3,textAlign:"center"});
function Pill({children,dark=false,style}:{children:React.ReactNode,dark?:boolean,style?:React.CSSProperties}){
 const f=useCurrentFrame(); const q=Math.min(1,f/11);
 return <div style={{border:"3px solid "+(dark?col.white:col.ink),borderRadius:45,background:dark?"#34464E":col.white,padding:"14px 30px",fontSize:27,fontFamily:font,fontWeight:850,letterSpacing:2.8,color:dark?col.white:col.ink,display:"inline-block",...style,
   opacity:q,transform:(style?.transform||"")+" translateY("+(Math.sin(f*.055)*3+(1-q)*-28)+"px)"}}>{children}</div>
}
function Card({children,style}:{children:React.ReactNode,style?:React.CSSProperties}){
 const f=useCurrentFrame();
 return <div style={{background:col.white,border:"4px solid "+col.ink,borderRadius:32,padding:45,boxShadow:"14px 15px 0 "+col.ink,fontFamily:font,color:col.ink,...style,
   transform:(style?.transform||"")+" translateY("+Math.sin(f*.075)*4+"px)"}}>{children}</div>
}
function Hourglass({size=400,dark=false,angle=0}:{size?:number,dark?:boolean,angle?:number}){
 const f=useCurrentFrame(), cycle=(f%84)/84;
 return <svg viewBox="0 0 300 300" width={size} height={size} style={{transform:"rotate("+(angle+Math.sin(f*.026)*1.7)+"deg)",filter:"drop-shadow(0px 12px 0 rgba(0,0,0,.12))"}}>
 <g fill="none" stroke={dark?col.white:col.ink} strokeWidth="12" strokeLinecap="round" strokeLinejoin="round"><path d="M65 40H235 M65 260H235"/><path d="M86 49C86 112 123 111 150 145C176 111 214 112 214 49 M86 251C86 187 122 182 150 147C175 182 214 187 214 251"/></g>
 <path d={"M107 "+(82+20*cycle)+" Q150 "+(102+22*cycle)+" 193 "+(82+20*cycle)+" Q190 100 150 127 Q112 100 107 "+(82+20*cycle)+"Z"} fill={col.green}opacity={1-cycle*.65}/>
 <path d={"M108 231 Q150 "+(224-43*cycle)+" 192 231 L192 245 L108 245Z"}fill={col.green}/>
 <path d="M150 150V223"stroke={col.green}strokeWidth="8"strokeLinecap="round"strokeDasharray="7 8"strokeDashoffset={-f*1.6}/>
 {Array.from({length:4},(_,i)=><circle key={i}cx={146+i*3}cy={186+(f*2+i*13)%47}r="3"fill={col.green}/>)}
 </svg>
}
function Back({dark=false,idx=0}:{dark?:boolean,idx?:number}){
 const f=useCurrentFrame();
 return <AbsoluteFill style={{backgroundColor:dark?col.ink:col.paper,
 backgroundImage:dark?"linear-gradient(rgba(255,255,255,.045) 1px, transparent 1px),linear-gradient(90deg,rgba(255,255,255,.045) 1px, transparent 1px)":"linear-gradient(rgba(22,34,40,.06) 1px, transparent 1px),linear-gradient(90deg,rgba(22,34,40,.06) 1px, transparent 1px)",
 backgroundSize:"66px 66px",backgroundPosition:(f*.43)+"px "+(f*.19)+"px"}}>
 <div style={{width:640,height:640,borderRadius:380,background:dark?"#658546":"#C3D997",filter:"blur(155px)",opacity:dark?.23:.43,position:"absolute",top:idx%2?1120:-300,left:idx%3? -330:750,
 transform:"translate("+Math.sin(f*.017)*67+"px,"+Math.cos(f*.013)*80+"px) scale("+(1+.04*Math.sin(f*.037))+")"}}/>
 <AmbientMotion dark={dark} idx={idx}/>
 </AbsoluteFill>
}
function Chrome({dark,idx}:{dark:boolean,idx:number}){
 return <div style={{position:"absolute",top:99,left:70,width:940,height:76,border:"3px solid "+(dark?"#AAB8BB":col.ink),borderRadius:18,background:dark?"#33434B":col.white,display:"flex",alignItems:"center",padding:"0 27px",boxSizing:"border-box",boxShadow:"0 9px 0 rgba(0,0,0,.13)"}}>
 <div style={{display:"flex",gap:12}}>{["#EAA770","#EBCD74",col.green].map((x,i)=><div key={i}style={{width:17,height:17,borderRadius:"50%",background:x,border:"2px solid #354047"}}/>)}</div>
 <div style={{fontFamily:font,fontSize:26,fontWeight:850,letterSpacing:1.1,color:dark?col.white:col.ink,textAlign:"center",flex:1}}>RENUNGAN <span style={{opacity:.45}}> / </span> MOTION</div>
 <div style={{fontFamily:font,fontWeight:900,fontSize:26,color:dark?col.white:col.ink}}>{String(idx+1).padStart(2,"0")}</div>
 </div>
}
function Footer({dark,idx,f,dur}:{dark:boolean,idx:number,f:number,dur:number}){
 return <><div style={{position:"absolute",bottom:181,left:84,width:910,display:"flex",gap:10}}>
 {Array.from({length:11},(_,i)=><div key={i}style={{height:11,borderRadius:7,flex:1,background:i<idx?col.olive:i>idx?(dark?"#53636B":"#C9D1C6"):"linear-gradient(90deg,"+col.green+" "+Math.floor(prog(f,0,dur)*100)+"%, "+(dark?"#53636B":"#C9D1C6")+" 0)"}}/>)}</div>
 <div style={{position:"absolute",bottom:121,left:86,fontFamily:font,fontWeight:750,fontSize:28,letterSpacing:1,color:dark?"#CFD9DB":col.muted}}>HR. AL-BUKHARI 6416</div>

 </>
}
function Slide({idx,duration}:{idx:number,duration:number}){
 const f=useCurrentFrame(), dark=[3,5,9,10].includes(idx), enter=prog(f,0,11);
 // Keep the outgoing scene opaque during incoming geometric reveal.
 const yy=(1-enter)*80, float=Math.sin(f/13)*12;
 const anim=(delay:number)=>({transform:"translateY("+((1-prog(f,delay,delay+12))*80+Math.sin(f*.065+delay)*4)+"px) rotate("+((1-prog(f,delay,delay+12))*(-6))+"deg)",opacity:prog(f,delay,delay+12)});
 return <AbsoluteFill>
 <Back dark={dark}idx={idx}/><Chrome dark={dark}idx={idx}/>
 <div style={{position:"absolute",top:275,left:70,width:940,height:1350,display:"flex",flexDirection:"column",alignItems:"center",boxSizing:"border-box",opacity:enter,transform:"translateY("+yy+"px)"}}>
 {idx===0&&<><Pill>PERTANYAAN UNTUK HATI</Pill><div style={{...title(),marginTop:102,fontSize:117}}><KineticWords text="Kapan perjalanan" f={f} start={4}/><KineticWords text="ini berakhir?" f={f} start={17} accent="berakhir?"/></div><div style={{marginTop:120,transform:"translateY("+float+"px)"}}><Hourglass size={410}/></div><div style={{...small(),marginTop:85,color:col.muted,textAlign:"center"}}><KineticPhrase text="Kita tidak tahu berapa lama waktu yang tersisa." f={f} start={30}/></div></>}
 {idx===1&&<><Pill>WAKTU YANG BERLALU</Pill><div style={{...title(),marginTop:101}}><KineticWords text="Umur terus" f={f} start={3}/><KineticWords text="berkurang." f={f} start={15} accent="berkurang."/></div><div style={{position:"relative",height:500,width:880,marginTop:65}}>
 <div style={{width:390,height:390,borderRadius:"50%",background:col.orange,border:"6px solid "+col.ink,position:"absolute",left:245,top:45,clipPath:"inset(0 0 50% 0)",transform:"translateY("+(float+prog(f,0,duration)*320)+"px) scale("+(1-prog(f,0,duration)*.15)+")"}}/>
 <div style={{position:"absolute",top:242,left:95,width:700,height:12,background:col.ink,borderRadius:8}}/>
 </div><Card style={{width:830,marginTop:-45}}><div style={{fontSize:27,letterSpacing:3,fontWeight:900,color:col.muted}}>SETIAP SENJA</div><div style={{fontSize:62,fontWeight:900,marginTop:13}}>Satu hari berlalu.</div><div style={{height:22,background:"#D6DED1",marginTop:29,borderRadius:16}}><div style={{height:22,width:(80-60*prog(f,0,duration))+"%",background:col.olive,borderRadius:16}}/></div></Card></>}
 {idx===2&&<><Pill>YANG KITA KEJAR</Pill><div style={{...title(),marginTop:105}}><KineticWords text="Kelak semua" f={f} start={4}/><KineticWords text="ditinggalkan." f={f} start={17} accent="ditinggalkan."/></div><div style={{width:860,marginTop:75}}>
 {["HARTA","JABATAN","PUJIAN"].map((x,i)=><Card key={x}style={{marginTop:23,height:140,display:"flex",alignItems:"center",gap:32,background:i===1?"#E3EAC7":col.white,...anim(i*8)}}><div style={{width:70,height:70,borderRadius:19,display:"grid",placeItems:"center",background:col.green,fontSize:42,border:"3px solid "+col.ink}}>↗</div><div style={{fontSize:54,fontWeight:900}}>{x}</div><div style={{marginLeft:"auto",fontSize:45,color:col.muted}}>→</div></Card>)}</div>
 <div style={{...small(),marginTop:82,color:col.muted}}><KineticPhrase text="Apa yang benar-benar kita bawa?" f={f} start={25}/></div></>}
 {idx===3&&<><Pill dark>JANGAN MENUNDA</Pill>
 <div style={{...title(col.white),fontSize:119,marginTop:64}}>
  <KineticWords text="ESOK?" f={f} start={4} accent="ESOK?" dark/>
  <KineticWords text="Bukan janji." f={f} start={14} accent="janji." dark/>
 </div>
 <PhoneReminder f={f}/>
 <div style={{fontFamily:serif,fontStyle:"italic",fontSize:50,fontWeight:620,color:col.white,marginTop:45,
  opacity:prog(f,24,45),transform:"translateY("+((1-prog(f,24,45))*33)+"px)"}}>
   Kembali kepada Allah hari ini.
 </div>
 </>}
 {idx===4&&<><Pill>NASIHAT RASULULLAH ﷺ</Pill><div style={{...title(),fontSize:98,marginTop:92}}><KineticWords text="Jadilah seperti" f={f} start={4}/><KineticWords text="musafir." f={f} start={17} accent="musafir."/></div><Card style={{width:900,marginTop:72,padding:"50px 52px",minHeight:620}}>
 <div style={{fontFamily:"Geeza Pro,serif",fontSize:68,lineHeight:1.8,direction:"rtl",textAlign:"center",opacity:prog(f,30,50),clipPath:"inset(0 "+((1-prog(f,30,57))*100)+"% 0 0)"}}>كُنْ فِي الدُّنْيَا كَأَنَّكَ غَرِيبٌ، أَوْ عَابِرُ سَبِيلٍ</div>
 <SourceUnderline f={f} start={26}/>
 <div style={{fontFamily:serif,fontWeight:700,fontSize:55,lineHeight:1.4,textAlign:"center",fontStyle:"italic",opacity:prog(f,42,59),transform:"translateY("+((1-prog(f,42,60))*29)+"px)"}}>“Jadilah di dunia seperti orang asing atau seorang musafir.”</div>
 <div style={{fontSize:29,fontWeight:850,textAlign:"center",color:col.olive,marginTop:31,letterSpacing:2,opacity:prog(f,58,72)}}>HR. AL-BUKHARI 6416</div></Card></>}
 {idx===5&&<><Pill dark>SUMBER HADIS</Pill><div style={{...title(col.white),fontSize:85,marginTop:123}}><KineticWords text="Nasihat yang" f={f} start={4}/><KineticWords text="terjaga sumbernya." f={f} start={16}/></div>
 <div style={{width:450,height:450,borderRadius:230,border:"10px solid "+col.green,marginTop:127,display:"grid",placeItems:"center",boxShadow:"0 0 0 35px rgba(182,206,102,.12)",transform:"scale("+(1+Math.sin(f/12)*.023)+")"}}><SourceSeal f={f}/></div>
 <div style={{fontFamily:font,fontSize:66,fontWeight:900,color:col.white,marginTop:100}}><KineticWords text="AL-BUKHARI" f={f} start={6}/><KineticWords text="6416" f={f} start={22} accent="6416" dark/></div>
 <div style={{...small("#CDD8D8"),marginTop:29}}><KineticPhrase text="Tentang perjalanan hidup kita." f={f} start={26} dark/></div></>}
 {idx===6&&<><Pill>DUNIA TEMPAT SINGGAH</Pill><div style={{...title(),fontSize:96,marginTop:104}}><KineticWords text="Jangan menetap" f={f} start={3}/><KineticWords text="di persinggahan." f={f} start={17} accent="persinggahan."/></div>
 <div style={{position:"relative",width:910,height:610,marginTop:90}}>
 <svg width="910" height="610" viewBox="0 0 910 610"><path d="M90 455 C 225 420,160 110,367 142 S 560 512,827 125"fill="none"stroke="#C3CBC4"strokeWidth="12"strokeLinecap="round"strokeDasharray="17 19"/>
 <path d="M90 455 C 225 420,160 110,367 142 S 560 512,827 125"fill="none"stroke={col.olive}strokeWidth="13"strokeDasharray={(1400*prog(f,0,duration))+" 1400"}strokeLinecap="round"/>
 <circle cx="90"cy="455"r="29"fill={col.green}stroke={col.ink}strokeWidth="7"/><circle cx="367"cy="142"r="29"fill={col.orange}stroke={col.ink}strokeWidth="7"/><circle cx="827"cy="125"r="29"fill={col.ink}stroke={col.white}strokeWidth="7"/><MovingRouteMarker f={f} duration={duration}/></svg>
 <Pill style={{position:"absolute",top:437,left:10}}>DUNIA</Pill><Pill style={{position:"absolute",top:26,left:211,background:"#F5E3C5"}}>SINGGAH</Pill><Pill style={{position:"absolute",top:12,right:0,background:col.green}}>JALAN</Pill>
 </div><div style={{...small(col.muted),marginTop:18}}><KineticPhrase text="Perjalanan masih panjang." f={f} start={24}/></div></>}
 {idx===7&&<><Pill>BEKAL PERJALANAN</Pill><div style={{...title(),fontSize:124,marginTop:114}}><KineticWords text="Bawa bekal." f={f} start={4} accent="bekal."/></div>
 <div style={{width:620,height:425,borderRadius:53,background:"#D1B28B",border:"8px solid "+col.ink,marginTop:160,boxShadow:"19px 22px 0 "+col.ink,position:"relative",transform:"translateY("+float+"px)"}}>
 <div style={{position:"absolute",width:265,height:74,border:"19px solid "+col.ink,borderBottom:0,borderRadius:"30px 30px 0 0",top:-75,left:161}}/><div style={{position:"absolute",top:0,bottom:0,left:138,width:43,background:"#B39470",borderLeft:"5px solid "+col.ink,borderRight:"5px solid "+col.ink}}/><div style={{position:"absolute",top:0,bottom:0,right:138,width:43,background:"#B39470",borderLeft:"5px solid "+col.ink,borderRight:"5px solid "+col.ink}}/>
 <div style={{position:"absolute",top:170,left:191,width:225,background:col.green,textAlign:"center",fontFamily:font,fontSize:51,fontWeight:900,padding:18,border:"5px solid "+col.ink,borderRadius:12}}>BEKAL</div><PackingTokens f={f}/></div>
 <div style={{display:"flex",gap:17,marginTop:100}}>{["IMAN","TOBAT","AMAL"].map((x,i)=><Pill key={x}style={{background:i===1?col.green:col.white,fontSize:32}}>✓ {x}</Pill>)}</div></>}
 {idx===8&&<><Pill>MULAI HARI INI</Pill><div style={{...title(),fontSize:96,marginTop:108}}><KineticWords text="Satu dosa." f={f} start={3}/><KineticWords text="Satu perbaikan." f={f} start={16} accent="perbaikan."/></div>
 <Card style={{marginTop:109,width:880}}><div style={{fontSize:32,letterSpacing:3,fontWeight:900,color:col.muted,marginBottom:33}}>DAFTAR LANGKAH</div>
 {["Sadari kesalahan","Berhenti mengulang","Mohon ampun"].map((s,i)=><div key={i}style={{display:"flex",gap:27,alignItems:"center",padding:"25px 5px",borderBottom:i===2?"none":"2px solid #D5DCD3",...anim(6+i*8)}}><CheckAnimation f={f} index={i} size={65}/><div style={{fontWeight:900,fontSize:47}}>{s}</div></div>)}</Card><div style={{...small(col.muted),marginTop:90}}><KineticPhrase text="Mulai malam ini. Bukan nanti." f={f} start={20}/></div></>}
 {idx===9&&<><Pill dark>MOHON AMPUNAN</Pill><div style={{...title(col.white),fontFamily:serif,fontSize:121,marginTop:181}}><KineticWords text="Istigfar." f={f} start={5}/></div>
 <div style={{width:740,height:3,background:col.green,marginTop:85}}/>
 <div style={{fontFamily:"Geeza Pro,serif",fontSize:127,lineHeight:1.5,color:col.green,direction:"rtl",marginTop:85,opacity:prog(f,11,34),textShadow:"0 0 "+(18+20*Math.sin(f*.065))+"px rgba(182,206,102,.32)",transform:"scale("+((0.86+0.14*prog(f,11,35))*(1+0.018*Math.sin(f*.05)))+")"}}>أَسْتَغْفِرُ اللّٰهَ</div>
 <div style={{...small(col.white),fontSize:53,marginTop:57,textAlign:"center"}}><KineticWords text="Aku memohon ampun" f={f} start={13}/><KineticWords text="kepada Allah." f={f} start={23}/></div>
 <div style={{...small("#CDDADE"),marginTop:118}}><KineticPhrase text="Dengan hati yang sungguh-sungguh." f={f} start={31} dark/></div></>}
 {idx===10&&<><Pill dark>RENUNGKAN SEJENAK</Pill><div style={{marginTop:136,transform:"translateY("+float+"px)"}}><Hourglass size={390}dark/></div>
 <div style={{...title(col.white),fontSize:106,marginTop:122}}><KineticWords text="DUNIA HANYA" f={f} start={3}/><KineticWords text="PERSINGGAHAN." f={f} start={15} accent="PERSINGGAHAN." dark/></div>
 <div style={{width:705*prog(f,9,42),height:3,background:col.green,marginTop:62,borderRadius:7}}/>
 <div style={{fontFamily:serif,fontSize:49,fontStyle:"italic",color:"#E0E8E5",marginTop:65}}><KineticPhrase text="Bekal apa yang kita bawa?" f={f} start={20} dark size={48}/></div>
 <Pill dark style={{marginTop:99,background:col.green,color:col.ink,border:"3px solid "+col.green}}>HR. AL-BUKHARI 6416</Pill></>}
 </div><Footer dark={dark}idx={idx}f={f}dur={duration}/>
 </AbsoluteFill>
}
const starts=timeline.segments.map((s,i)=>i===0?0:Math.floor((s.start-.55)*FPS));
export const MotionDakwahVideo:React.FC=()=> <AbsoluteFill>
 <Audio src={staticFile("assets/motion-dakwah-single-puck-20261124/narasi-gemini-puck-mixed.m4a")}/>
 {timeline.segments.map((s,i)=>{const from=starts[i],end=i+1<timeline.segments.length?Math.ceil((timeline.segments[i+1].start+.33)*FPS):TOTAL;
 return <Sequence key={i}from={from}durationInFrames={end-from}><TransitionScreen index={i===0?0:1}><Slide idx={i}duration={end-from}/></TransitionScreen></Sequence>})}
 </AbsoluteFill>;
export const MotionDakwahCover:React.FC=()=> <AbsoluteFill style={{background:col.ink}}>
 <Back dark idx={10}/><Chrome dark idx={0}/>
 <div style={{position:"absolute",top:330,left:70,width:940,display:"flex",alignItems:"center",flexDirection:"column"}}>
 <Pill dark style={{background:col.green,color:col.ink,borderColor:col.green}}>RENUNGAN • AKHIRAT</Pill>
 <div style={{marginTop:110}}><Hourglass size={430}dark/></div>
 <div style={{...title(col.white),fontSize:119,marginTop:130}}>DUNIA HANYA<br/><span style={{color:col.green}}>PERSINGGAHAN</span></div>
 <div style={{fontFamily:serif,fontSize:55,fontStyle:"italic",color:"#E3E8E7",marginTop:81}}>Apa bekal perjalananmu?</div>
 <div style={{width:710,height:3,background:"#839396",marginTop:92}}/>
 <div style={{fontFamily:font,fontSize:37,fontWeight:850,letterSpacing:2,color:col.white,marginTop:44}}>HR. AL-BUKHARI 6416</div>
 </div>
 </AbsoluteFill>;
export const MotionDakwahCompositions:React.FC=()=> <><Composition id="MotionDakwahKineticV3"component={MotionDakwahVideo}durationInFrames={TOTAL}fps={FPS}width={WIDTH}height={HEIGHT}/><Composition id="MotionDakwahKineticSampul"component={MotionDakwahCover}durationInFrames={1}fps={FPS}width={WIDTH}height={HEIGHT}/></>;