import React from "react";
import {registerRoot} from "remotion";
import {MotionDakwahCompositions} from "./MotionDakwahKineticV3";
registerRoot(MotionDakwahCompositions);
