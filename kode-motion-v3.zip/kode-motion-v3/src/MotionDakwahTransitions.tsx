import React from "react";
import {AbsoluteFill, useCurrentFrame} from "remotion";

export type MotionTransitionType =
  | "diagonal"
  | "shutters"
  | "iris"
  | "flip"
  | "reverse"
  | "portal"
  | "split";

// Each incoming scene uses a different purposeful, vector-based reveal.
// No stock overlays or imported transition presets.
const TRANSITIONS:MotionTransitionType[]=[
 "diagonal",  // first next scene
 "shutters",
 "iris",
 "flip",
 "reverse",
 "shutters",
 "portal",
 "split",
 "iris",
 "diagonal"
];
export const transitionByScene=(idx:number):MotionTransitionType|undefined=>
 idx===0?undefined:TRANSITIONS[(idx-1)%TRANSITIONS.length];

const W=1080, H=1920, ANIM=24;
const ease=(n:number)=>{const t=Math.max(0,Math.min(1,n));return t*t*(3-2*t);};
const swatch="#DCE77B";
const stripe="linear-gradient(90deg,#26393B 0%,#A2B94A 12%,#C8DC68 44%,#FBEC8D 70%,#F6CE55 88%,rgba(246,206,85,0) 100%)";

type Props={
 index:number;
 children:React.ReactNode;
};

export const TransitionScreen:React.FC<Props>=({index,children})=>{
 const f=useCurrentFrame(), kind=transitionByScene(index);
 const p=ease(f/ANIM);
 if (!kind || f>=ANIM) return <AbsoluteFill>{children}</AbsoluteFill>;
 
 if(kind==="diagonal"||kind==="reverse"){
  const forward=kind==="diagonal";
  const center=forward?-550+2200*p:1630-2200*p;
  const top=center+360;
  const bottom=center-360;
  const mask=forward
   ? "polygon(0 0,"+top+"px 0,"+bottom+"px 100%,0 100%)"
   : "polygon("+top+"px 0,100% 0,100% 100%,"+bottom+"px 100%)";
  return <AbsoluteFill>
    <AbsoluteFill style={{clipPath:mask}}>{children}</AbsoluteFill>
    <div style={{
     position:"absolute",top:-350,left:center-80,width:160,height:2700,
     transform:"rotate(20.5deg)", transformOrigin:"center center",
     background:stripe,boxShadow:"0 0 55px rgba(45,56,31,.14)",
     opacity:f<2?.5:1,pointerEvents:"none"
    }}/>
    <div style={{
     position:"absolute",top:-350,left:center+42,width:23,height:2700,
     transform:"rotate(20.5deg)",transformOrigin:"center center",
     background:swatch,filter:"blur(5px)",opacity:.72
    }}/>
   </AbsoluteFill>;
 }
 
 if(kind==="shutters"){
  const count=6;
  return <AbsoluteFill>
   {Array.from({length:count},(_,k)=>{
    const q=ease((f-k*1.55)/(ANIM-7.8));
    const dy=(1-q)*(k%2?H:-H);
    const left=k*100/count,right=100-(k+1)*100/count;
    return <AbsoluteFill key={k} style={{
      clipPath:"inset(0 "+right+"% 0 "+left+"%)",
      transform:"translateY("+dy+"px)",
      filter:q<1?"drop-shadow(10px 0 10px rgba(0,0,0,.15))":"none"
    }}>{children}</AbsoluteFill>;
   })}
   {Array.from({length:count-1},(_,k)=>{
    const q=ease((f-k*1.55)/(ANIM-7.8));
    const dy=(1-q)*(k%2?H:-H);
    return <div key={k} style={{
     position:"absolute",left:((k+1)*100/count)+"%",width:7,height:H,
     transform:"translateY("+dy+"px)",
     background:k%2?"#D1DE7C":"#F6D578",opacity:q>.03&&q<.99?.8:0
    }}/>;
   })}
  </AbsoluteFill>;
 }

 if(kind==="iris"){
  const cx=index%2===0?824:250,cy=index%2===0?460:1390;
  const radius=2520*p;
  return <AbsoluteFill>
   <AbsoluteFill style={{clipPath:"circle("+radius+"px at "+cx+"px "+cy+"px)"}}>{children}</AbsoluteFill>
   <svg width={W}height={H}viewBox="0 0 1080 1920" style={{position:"absolute",inset:0,pointerEvents:"none"}}>
    <circle cx={cx} cy={cy} r={radius} fill="none" stroke="#B0C957"strokeWidth="51"opacity={p>.92?.4:1}/>
    <circle cx={cx} cy={cy} r={radius+27} fill="none" stroke="#F5DB83"strokeWidth="10" opacity={p>.92?0:.8}/>
   </svg>
  </AbsoluteFill>;
 }

 if(kind==="flip"){
  const degrees=-89*(1-p);
  return <AbsoluteFill>
   <AbsoluteFill style={{
     transform:"perspective(1700px) rotateY("+degrees+"deg)",
     transformOrigin:"0% 50%",
     boxShadow:p<1?"-45px 0 70px rgba(11,21,28,.32)":"none",
     backfaceVisibility:"hidden"
   }}>{children}</AbsoluteFill>
   <div style={{position:"absolute",left:0,top:0,width:Math.max(0,28*(1-p)),height:H,
     background:"linear-gradient(90deg,#263C40,#B2CA62)",opacity:.85
   }}/>
  </AbsoluteFill>;
 }

 if(kind==="portal"){
  const outside=42*(1-p);
  const corner=130*(1-p);
  const zoom=1.16-.16*p;
  return <AbsoluteFill>
   <AbsoluteFill style={{
    clipPath:"inset("+outside+"% "+outside+"% "+outside+"% "+outside+"% round "+corner+"px)",
    transform:"scale("+zoom+")"
   }}>{children}</AbsoluteFill>
   <div style={{
    position:"absolute",top:(42*(1-p))+"%",left:(42*(1-p))+"%",
    width:(100-84*(1-p))+"%",height:(100-84*(1-p))+"%",
    border:"10px solid #BED56D",borderRadius:corner,
    boxSizing:"border-box",opacity:p>.92?0:(1-p)*.95,
    boxShadow:"0 0 0 30px rgba(35,50,54,.10)"
   }}/>
  </AbsoluteFill>;
 }

 if(kind==="split"){
  const q=ease(f/ANIM);
  return <AbsoluteFill>
   <AbsoluteFill style={{
    clipPath:"inset(0 0 50% 0)",
    transform:"translateX("+((1-q)*-W)+"px)"
   }}>{children}</AbsoluteFill>
   <AbsoluteFill style={{
    clipPath:"inset(50% 0 0 0)",
    transform:"translateX("+((1-q)*W)+"px)"
   }}>{children}</AbsoluteFill>
   <div style={{position:"absolute",top:"50%",left:0,width:W,height:17,
    background:"#D4E47F",transform:"translateY(-50%) scaleX("+Math.sin(Math.PI*p)+")",
    boxShadow:"0 0 30px rgba(232,195,90,.50)",opacity:p>.9?0:1}}/>
  </AbsoluteFill>;
 }
 return <AbsoluteFill>{children}</AbsoluteFill>;
};
