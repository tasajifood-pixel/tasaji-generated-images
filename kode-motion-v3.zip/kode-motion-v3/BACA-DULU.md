# Kode mentah Video Dakwah Motion Editorial V3 (24 Nov 2026)
Proyek: ~/Projects/tasaji-video-studio (Remotion, React/TypeScript), MacBook Abi.

Berkas:
- src/MotionDakwahKineticV3.tsx      — otak video: susunan adegan (Slide), alur waktu, audio, sampul (komposisi MotionDakwahKineticV3 & MotionDakwahKineticSampul)
- src/MotionDakwahKineticParts.tsx   — komponen gerak: KineticWords/KineticPhrase (teks per kata), PhoneReminder, CheckAnimation, PackingTokens, MovingRouteMarker, SourceSeal, dll.
- src/MotionDakwahTransitions.tsx    — 7 mesin transisi (diagonal, shutters, iris, flip, reverse, portal, split)
- src/MotionDakwahFonts.css          — font (Bricolage Grotesque, Plus Jakarta Sans, Fraunces)
- src/motion-single-puck-timeline.json — waktu tiap segmen narasi (dari audio Gemini Puck)
- src/entry-motion-dakwah-kinetic-v3.tsx — titik masuk render
- TEMPLATE-MOTION-EDITORIAL.md       — konsep template (palet, transisi, aturan syariat)

Render (di folder proyek):
  npx remotion render src/entry-motion-dakwah-kinetic-v3.tsx MotionDakwahKineticV3 out/v3.mp4
  npx remotion still  src/entry-motion-dakwah-kinetic-v3.tsx MotionDakwahKineticSampul out/v3-sampul.jpg
Aset (font, audio) ada di folder public/ proyek — tidak ikut paket ini.
Versi data-driven untuk konten baru: src/DhuhaMotionEditorial.tsx (gaya motion-editorial-dinamis).
